﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EShop
{
    public class Products
    {
        public Products(int id, string name, decimal price, string manufecturer)
        {
            Id = id;
            Name = name;
            Price = price;
            Manufacturer = manufecturer;
        }

        public int Id { get; private set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Manufacturer { get; set; }

        public void Display()
        {
            Console.WriteLine($"ID :{Id}\tName :{Name}\tPrice :{Price}\tManufecturer : {Manufacturer} ");
        }
    }
}
