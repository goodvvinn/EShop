﻿using System;

namespace EShop
{
    public class User
    {
        public User()
        {
        }

        public User(string name, string phoneNumber, string email)
        {
            Name = name;
            PhoneNumber = phoneNumber;
            Email = email;
        }

        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }

        public void GetUser()
        {
            while (true)
            {
                Console.WriteLine("*******Please, enter your name*******");
                Name = Console.ReadLine();
                Console.WriteLine("Please, enter your phone number");
                PhoneNumber = Console.ReadLine();
                Console.WriteLine("Please, enter your Email");
                Email = Console.ReadLine();
                if (Name != string.Empty && PhoneNumber != string.Empty && Email != string.Empty)
                {
                    Console.WriteLine($"Hello {Name}, Welcome!");
                    break;
                }
                else
                {
                    Console.WriteLine("Sorry, not all required fields are filled");
                    Console.WriteLine();
                }
            }
        }
    }
}
