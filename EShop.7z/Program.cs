﻿using System;

namespace EShop
{
    public class Program
    {
        public static void Main(string[] args)
        {
            User consumer = new User();
            consumer.GetUser();

            Console.WriteLine("Please,choose the item from the list below");
            Products motherboard = new Products(1, "P5S", 400, "Sony");
            Products memory = new Products(2, "DDR3", 200, "Hynix");
            Products cpu = new Products(3, "CoreI5", 350, "Intel");
            Products body = new Products(4, "I400", 100, "CoolerMaster");
            Products monitor = new Products(5, "24", 300, "samsung");

            motherboard.Display();
            memory.Display();
            cpu.Display();
            body.Display();
            monitor.Display();
        }
    }
}
